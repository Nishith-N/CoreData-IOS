//
//  myVariables.swift
//  coreDataTask2
//
//  Created by Byot on 05/07/22.
//

import Foundation

var stdArray : NSArray = NSArray()
