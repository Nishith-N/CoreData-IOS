//
//  savedViewController.swift
//  coreDataTask2
//
//  Created by Byot on 05/07/22.
//

import UIKit
import CoreData

class savedViewController: UIViewController {

    @IBOutlet var addBtn: UIButton!
    @IBOutlet var stdDepTxt: UITextField!
    @IBOutlet var stdRollNoTxt: UITextField!
    @IBOutlet var stdNameTxt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func addBtnAction(_ sender: UIButton) {
        
        let app = UIApplication.shared.delegate as! AppDelegate //CRUD
                let context = app.persistentContainer.viewContext //CRUD
                let newStudent = NSEntityDescription.insertNewObject(forEntityName: "StudentDetails", into: context) //Create
                newStudent.setValue(self.stdNameTxt.text!, forKey: "studentName")
                newStudent.setValue(self.stdRollNoTxt.text!, forKey: "studentRollNo")
                newStudent.setValue(self.stdDepTxt.text!, forKey: "studentDep")
                do {
                    try context.save()
                } catch let err as NSError {
                    print(err.localizedDescription)
                }
                self.navigationController?.popViewController(animated: true)
    }
    
  

}
