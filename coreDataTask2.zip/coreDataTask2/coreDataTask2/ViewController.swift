//
//  ViewController.swift
//  coreDataTask2
//
//  Created by Byot on 05/07/22.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
var sendData = 0
    @IBOutlet var myTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        myTableView.delegate = self
        myTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
           let app = UIApplication.shared.delegate as! AppDelegate //CRUD
           let context = app.persistentContainer.viewContext //CRUD
           let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "StudentDetails")
           do {
               stdArray = try context.fetch(fetchRequest) as NSArray
               DispatchQueue.main.async {
                   self.myTableView.reloadData()
               }
           } catch let err as NSError {
               print(err.localizedDescription)
           }
          
        for val in stdArray
        {
            print(val)
        }
     
        
        
            
       }
    
    func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return stdArray.count
        }
    private func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCell.EditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if (editingStyle == UITableViewCell.EditingStyle.delete){
            print("DELETED")
        }
    }
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "customTableViewCell", for: indexPath) as! customTableViewCell
            let stdObject = stdArray.object(at: indexPath.row) as! NSManagedObject //array to dict
            cell.stdNameLbl.text = "\(stdObject.value(forKey: "studentName")!)"
            cell.stdRollNoLbl.text = "\(stdObject.value(forKey: "studentRollNo")!)"
            cell.stdDepLbl.text = "\(stdObject.value(forKey: "studentDep")!)"
            
            return cell
        }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       
        let vc = storyboard?.instantiateViewController(withIdentifier: "updateViewController") as! updateViewController
        sendData = indexPath.row
        vc.myRow = sendData
        let stdObject = stdArray.object(at: indexPath.row) as! NSManagedObject
        vc.stdDict = stdObject
        navigationController?.pushViewController(vc, animated: true)
    }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 180
        }


}

