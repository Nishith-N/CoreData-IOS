//
//  updateViewController.swift
//  coreDataTask2
//
//  Created by Byot on 05/07/22.
//

import UIKit
import CoreData

class updateViewController: UIViewController {

    @IBOutlet var stdDepTxt: UITextField!
    @IBOutlet var stdRollNoTxt: UITextField!
    @IBOutlet var stdNameTxt: UITextField!
    var myRow = 0
    var stdDict : NSManagedObject = NSManagedObject()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    @IBAction func deleteBtnAction(_ sender: UIButton) {
        let app = UIApplication.shared.delegate as! AppDelegate //CRUD
                let context = app.persistentContainer.viewContext //CRUD
        context.delete(stdArray[myRow] as! NSManagedObject)
        do {
        try context.save()
        }
        catch {
            // Handle Error
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func updateBtnAction(_ sender: Any) {
        if(stdDepTxt.text != "" && stdNameTxt.text != "" && stdRollNoTxt.text != "")
        {

        let app = UIApplication.shared.delegate as! AppDelegate //CRUD
                let context = app.persistentContainer.viewContext //CRUD
            
//                let newStudent = NSEntityDescription.insertNewObject(forEntityName: "StudentDetails", into: context) //Create
                stdDict.setValue(self.stdNameTxt.text!, forKey: "studentName")
                stdDict.setValue(self.stdRollNoTxt.text!, forKey: "studentRollNo")
                stdDict.setValue(self.stdDepTxt.text!, forKey: "studentDep")
                do {
                    try context.save()
                } catch let err as NSError {
                    print(err.localizedDescription)
                }
                self.navigationController?.popViewController(animated: true)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
