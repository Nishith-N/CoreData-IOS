//
//  customTableViewCell.swift
//  coreDataTask2
//
//  Created by Byot on 05/07/22.
//

import UIKit

class customTableViewCell: UITableViewCell {

    @IBOutlet var stdDepLbl: UILabel!
    @IBOutlet var stdRollNoLbl: UILabel!
    @IBOutlet var stdNameLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
